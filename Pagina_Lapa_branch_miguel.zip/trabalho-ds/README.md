# Página pessoal | Miguel Lapa

Minha página pessoal desenvolvida em HTML e CSS. Nela apresento minha personalidade, meus valores, hobbies, jogos e artistas favoritos, lugares que visitei e destinos que quero conhecer. Também falo sobre minha relação com os esportes, o São Paulo FC, Neymar como inspiração, meus objetivos e sonhos, curiosidades pessoais e o projeto VOLTA.

## Novas seções

- **Minha relação com os esportes:** como Neymar me inspirou, meu interesse por futebol e vôlei e o que aprendo praticando.
- **Meus objetivos e sonhos:** viagens, desenvolvimento pessoal e momentos que quero viver.
- **Curiosidades sobre mim:** time, ídolo, jogos, música e lugares que quero conhecer.

## Tecnologias

- HTML5 e CSS3
- CSS Grid e Flexbox
- Efeitos de hover e layout responsivo
- Bootstrap 5 para auxiliar no estilo
- Sem JavaScript

## Como abrir

Extraia o ZIP, abra a pasta `trabalho-ds` e clique duas vezes em `Pagina_Lapa.html`. O `style.css` e as imagens devem permanecer na mesma estrutura de pastas. As fotos utilizadas ficam salvas no projeto e funcionam sem internet; o Bootstrap é opcional e carregado por CDN.

## Organização

- `Pagina_Lapa.html`: estrutura e textos da página
- `style.css`: estilo, efeitos e responsividade
- `imagens/perfil.jpg`: foto de perfil
- `imagens/volta.png` e `imagens/spfc.png`: marcas exibidas na página
- `imagens/fotos/`: fotografias de destinos e do Pico do Jaraguá
- `imagens/hobbies/`: imagens de vôlei, videogame e Neymar
- `imagens/jogos/`: artes dos jogos favoritos
- `imagens/musicas/`: imagens dos artistas favoritos

Os cartões de vôlei, futebol (Neymar) e videogame usam as imagens enviadas pelo autor. As capas da seção de jogos favoritos foram mantidas. As fotografias e artes enviadas pelo autor podem ter direitos pertencentes aos seus respectivos titulares.

## Autor

Miguel Lapa Sperandio
